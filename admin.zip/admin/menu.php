  <ul class="sidebar-menu">
  <li>
              <a href='index.php?aksi=home'>
                <i class='fa fa-dashboard'></i> <span>Dashboard</span> 
              </a> 
 </li>
 <li>      
      <a href="index.php?aksi=profil">
                  <i class="fa fa-briefcase"></i> <span>SETTING</span>
                </a>
              </li>
<li class='treeview'>
               <a href='#'>
                 <i class='fa fa-bank'></i>
                 <span>MASTER DATA</span>
               </a>
               <ul class='treeview-menu'>
                <li><a href='index.php?aksi=informasi'><i class='fa fa-arrows-h'></i>INFORMASI</a></li>
                <li><a href='index.php?aksi=galeri'><i class='fa fa-arrows-h'></i>GALERY</a></li>
                <li><a href='index.php?aksi=profil'><i class='fa fa-arrows-h'></i>PROFIL</a></li>
                <li><a href='index.php?aksi=kritik'><i class='fa fa-arrows-h'></i>KRITIK</a></li>
   
               </ul>
</li>
<li><a href="index.php?aksi=admin"><i class="fa fa-users"></i> <span>ADMIN</span></a></li>
<li><a href="logout.php"><i class="fa fa-sign-out"></i> <span>LOGOUT</span></a></li>
</ul>